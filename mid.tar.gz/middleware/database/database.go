package database

import (
	config "SaaMD/middleware/config"
	log "SaaMD/middleware/log"
	models "SaaMD/middleware/models"
	"github.com/gin-gonic/gin"
	"github.com/go-pg/pg"
	"github.com/go-pg/pg/orm"
	"strings"
)

var db *pg.DB

//Connect to postgressql DB
func connectDB() *pg.DB {
	configuration := config.GetConfig()
	Database := configuration.Database
	return pg.Connect(&pg.Options{User: Database.User, Password: Database.Password, Database: Database.Name})
}

// InitializeDB function is use to intialize db connection
// this also cache db connection in global variable so that every request can reuse the open db connection
func InitializeDB(c *gin.Context) {
	if db != nil {
		c.Set("DB", db)
	} else {
		db = connectDB()
		c.Set("DB", db)
	}
}

// CreateSchema is use to create schema of all existing tables
func CreateSchema() error {
	db := connectDB()
	defer db.Close()

	for _, model := range []interface{}{&models.User{}, &models.Environment{}, &models.Datasource{}, &models.Image{}, &models.Service{}, &models.Pipeline{}} {
		err := db.CreateTable(model, &orm.CreateTableOptions{
			FKConstraints: true,
			//IfNotExists: true,
		})
		if err != nil {
			//when table is already present in database, then no need to handle that error
			// #42P07 table already present in database error code
			isAvailable := strings.Contains(err.Error(), "#42P07")
			if isAvailable == false {
				log.Error(nil, err.Error())
			}
		}
	}
	return nil
}

// DropTables is use to drop all the tables
// this function is mainly used in test cases to clear database
func DropTables() error {
	if db == nil {
		db = connectDB()
	}
	defer db.Close()

	for _, model := range []interface{}{&models.User{}, &models.Environment{}, &models.Datasource{}, &models.Image{}, &models.Service{}, &models.ServiceExeInstance{}, &models.Pipeline{}, &models.PipelineExeInstance{} } {
		err := db.DropTable(model, &orm.DropTableOptions{})
		if err != nil {
			log.Error(nil, err.Error())
			return err
		}
	}
	db = nil
	return nil
}
