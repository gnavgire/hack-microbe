package models

import "time"

// Datasource table is use to upload the input xml file
type Datasource struct {
	tableName       struct{}  `sql:"datasource"`
	ID              int64     `sql:"id"`
	Type            string    `sql:"type"`
	Name            string    `sql:"name"`
	Description     string    `sql:"description"`
	Path            string    `sql:"path"`
	Pipelineid      int64     `sql:"pipelineid"`
	Creator         *User     `pg:"fk:createdby"`
	CreatedBy       int64     `sql:"createdby"`
	Isdisabled      bool      `sql:"isdisabled"`
	CreatedDateTime time.Time `sql:"createddatetime,default:now()"`
}
