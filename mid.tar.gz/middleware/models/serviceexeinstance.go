package models

import "time"

// ServiceExeInstance table is use to store all services data whether that is container service or executable
type ServiceExeInstance struct {
	tableName  struct{} `sql:"serviceexeinstance"`
	ID         int64    `sql:",pk,notnull"`
	ServiceId  int64    `sql:"serviceid"`
	PipelineId int64    `sql:"pipelineid"`
	Input      string   `sql:",notnull"`
	Output     string   `sql:",notnull"`
	Status     string   `sql:",notnull"`
	Error      string
	StartTime  time.Time `sql:"starttime,default:now()"`
	EndTime    time.Time `sql:"endtime,default:now()"`
}
