package models

import "time"

// PipelineExeInstance table is use to store all pipeline data
type PipelineExeInstance struct {
	tableName      struct{} `sql:"pipelineexeinstance"`
	ID             int64    `sql:",pk,notnull"`
	ExecutedBy     string   `pg:"executedby"`
	PipelineId     int64    `sql:"pipelineid"`
	logId          int64    `sql:"logid"`
	PipelineOutput string   `sql:"pipelineoutput"`
	Status         string   `sql:"status,notnull"`
	Error          string
	StartTime      time.Time `sql:"starttime,default:now()"`
	EndTime        time.Time `sql:"endtime,default:now()"`
}
