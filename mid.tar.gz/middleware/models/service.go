package models

import "time"

// Service table is use to store all services data whether that is container service or executable
type Service struct {
	ID              int64        `sql:",pk,notnull"`
	Environment     *Environment `pg:"fk:environmentid"`
	EnvironmentID   int64        `sql:"environmentid"`
	Type            string       `sql:",notnull"`
	Image           *Image       `pg:"fk:imageid"`
	ImageID         int64        `sql:"imageid"`
	Creator         *User        `pg:"fk:createdby"`
	CreatedBy       int64        `sql:"createdby"`
	Name            string       `sql:",notnull"`
	Description     string       `sql:",notnull"`
	ExecutableName  string       `sql:",notnull"`
	InputFilePath   string       `sql:",notnull"`
	OutputFilePath  string       `sql:",notnull"`
	Parameters      string       `sql:",notnull"`
	Status          string       `sql:",notnull"`
	Error           string
	IsDisable       bool      `sql:"isdisabled,default:false"`
	CreatedDateTime time.Time `sql:"createddatetime,default:now()"`
}
