package models

import "time"

// Environment table is use to run container on different environments like local or cloud
// This table is for future use
type Environment struct {
	ID              int64     `sql:",pk,notnull"`
	Name            string    `sql:",notnull"`
	Description     string    `sql:",notnull"`
	IsDisable       bool      `sql:"isdisabled,default:false"`
	CreatedDateTime time.Time `sql:"createddatetime,default:now()"`
}
