package models

import "time"

// User table is use to store user data
type User struct {
	ID              int64     `sql:",pk,notnull"`
	UserName        string    `sql:",notnull,unique"`
	Password        string    `sql:",notnull"`
	FirstName       string    `sql:",notnull"`
	LastName        string    `sql:",notnull"`
	Email           string    `sql:",notnull"`
	CreatedDateTime time.Time `sql:"createddatetime,default:now()"`
}
