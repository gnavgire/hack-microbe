package models

import "time"

// Image table is use to store container images
type Image struct {
	ID                   int64  `sql:",pk,notnull"`
	Name                 string `sql:",notnull"`
	Version              string `sql:",notnull"`
	RegistryUserName     string `sql:"registryusername"`
	RegistryUserPassword string `sql:"registryuserpassword"`
	Status               string `sql:",notnull"`
	Error                string
	IsDisable            bool      `sql:"isdisabled,default:false"`
	CreatedDateTime      time.Time `sql:"createddatetime,default:now()"`
}
