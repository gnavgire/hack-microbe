package models

import "time"

// Pipeline table is use to store all pipeline data
type Pipeline struct {
	tableName       struct{} `sql:"pipeline"`
	ID              int64    `sql:",pk,notnull"`
	Creator         *User    `pg:"fk:createdby"`
	CreatedBy       int64    `sql:"createdby"`
	Name            string   `sql:"name,notnull"`
	Description     string   `sql:"description,notnull"`
	Version         string   `sql:"version,notnull"`
	Definition      string   `sql:"definition,notnull"`
	Status          string   `sql:"status,notnull"`
	Error           string
	IsDisable       bool      `sql:"isdisabled,default:false"`
	CreatedDateTime time.Time `sql:"createddatetime,default:now()"`
}
