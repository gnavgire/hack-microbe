package main

import (
	config "SaaMD/middleware/config"
	database "SaaMD/middleware/database"
	log "SaaMD/middleware/log"
	utils "SaaMD/middleware/utils"
	"context"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"
)

var (
	srv = &http.Server{}
	// stop is a channel that tells the service to stop.  As seen
	// later we will make a highly destructive deathblow endpoint
	// so that in test we can conclude the test and turn the service off.
	stop chan bool
	// testMode is a bool that allows for deathpunch endpoint to exist or
	// not exist... we don't want that running in production
	testMode bool = false
)

// runMain - entry-point to perform external testing of service, this is
// where go test will enter main.  we have to setup test mode in here, as
// well as the stop channel so we can stop the service
func runMain() {
	// start the stop channel
	stop = make(chan bool)
	// put the service in "testMode"
	testMode = true
	// run the main entry point
	go main()
	// watch for the stop channel
	<-stop
	// stop the graceful server
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := srv.Shutdown(ctx); err != nil {
		fmt.Println("Server Shutdown:  ", err)
	}

	fmt.Println("Shutting down Server ...")
}

func main() {
	// configuration
	configuration := config.GetConfig()

	//Initialize logging
	log.InitializeLogging()

	// create database schema
	database.CreateSchema()

	//setting up router
	router := setupRouter()

	//connect with database
	router.Use(database.InitializeDB)

	//Configure routes
	routes(router)

	srv = &http.Server{
		Addr:    configuration.Port,
		Handler: router,
	}

	go func() {
		// service connections
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Error(nil, utils.Concat("listen to", err.Error()))
		}
	}()

	// Wait for interrupt signal to gracefully shutdown the server with
	// a timeout of 5 seconds.
	quit := make(chan os.Signal, 1)
	// kill (no param) default send syscanll.SIGTERM
	// kill -2 is syscall.SIGINT
	// kill -9 is syscall. SIGKILL but can"t be catch, so don't need add it
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	log.Warn(nil, "Shutting down Server ...")

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := srv.Shutdown(ctx); err != nil {
		log.Warn(nil, utils.Concat("Server Shutdown:  ", err.Error()))
	}

	log.Info(nil, "Engine shut down ")
}
