package utils

import (
	config "SaaMD/middleware/config"
	database "SaaMD/middleware/database"
	"bytes"
	"encoding/json"
	"github.com/gin-contrib/sessions"
	"github.com/gin-gonic/gin"
	"net/http/httptest"
	"reflect"
)

// GetFieldValue use to get value from interface
func GetFieldValue(entity interface{}, field string) string {
	r := reflect.ValueOf(entity)
	f := reflect.Indirect(r).FieldByName(field)
	return string(f.String())
}

//ValidateRequest is use to check mandatory fields in request
func ValidateRequest(mandatory []string, entity interface{}) bool {
	for i := 0; i < len(mandatory); i++ {
		if GetFieldValue(entity, mandatory[i]) == "" {
			return false
		}
	}

	return true
}

// Concat is use to concatinate two string
func Concat(string1, string2 string) string {
	buf := bytes.Buffer{}
	buf.WriteString(string1)
	buf.WriteString(string2)
	return buf.String()
}

// SaveSession is use to save the cookie based user session
func SaveSession(c *gin.Context, user map[string]string) {
	session := sessions.Default(c)
	userData, _ := json.Marshal(user)
	session.Set("user", string(userData))
	session.Save()
}

// GetSession is use to get the cookie based user session
func GetSession(c *gin.Context) map[string]string {
	session := sessions.Default(c)
	user := session.Get("user")
	if user == nil {
		return nil
	}

	var dat map[string]string
	err := json.Unmarshal([]byte(user.(string)), &dat)
	if err != nil {
		return nil
	}
	return dat
}

// CreateTestContext is to create new gin Context
// this is mainly use in test cases
func CreateTestContext() (c *gin.Context, w *httptest.ResponseRecorder) {
	gin.SetMode(gin.TestMode)
	w = httptest.NewRecorder()
	c, _ = gin.CreateTestContext(w)
	database.CreateSchema()
	database.InitializeDB(c)

	// set configuration in request
	configuration := config.GetConfig()
	c.Set("Config", configuration)

	return c, w
}
