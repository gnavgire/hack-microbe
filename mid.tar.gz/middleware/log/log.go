package log

import (
	config "SaaMD/middleware/config"
	"fmt"
	"github.com/gin-gonic/gin"
	log "github.com/sirupsen/logrus"
	"os"
)

// InitializeLogging call when server starts
// this function set logging level according to GO_ENV
func InitializeLogging() {
	configuration := config.GetConfig()
	logConfig := configuration.Log

	filePath := logConfig.LogFile
	f, err := os.OpenFile(filePath, os.O_WRONLY|os.O_APPEND|os.O_CREATE, 0644)

	// set format
	switch configuration.Environment {
	case "production":
		fmt.Println("in production")
	case "staging":
		fmt.Println("in staging")
	default:
		formatter := new(log.TextFormatter)
		formatter.TimestampFormat = "01-02-2019 01:02:03"
		formatter.FullTimestamp = true
		log.SetFormatter(formatter)
	}

	// set Default log level
	switch logConfig.LogLevel {
	case "info":
		log.SetLevel(log.InfoLevel)
	case "warn":
		log.SetLevel(log.WarnLevel)
	case "error":
		log.SetLevel(log.ErrorLevel)
	case "fatal":
		log.SetLevel(log.FatalLevel)
	case "panic":
		log.SetLevel(log.PanicLevel)
	}

	if err != nil {
		fmt.Println(err)
		os.Exit(2)
	} else {
		log.SetOutput(f)
	}

}

func addLog(level string, c *gin.Context, message string) {
	var requestLogger *log.Entry
	if c != nil {
		method := c.Request.Method
		logger := log.Fields{
			"url": c.Request.URL.Path,
		}

		switch method {
		case "POST":
			data, _ := c.GetRawData()
			logger["body"] = string(data)
			fmt.Println("in POST", logger)
		case "PUT":
			data, _ := c.GetRawData()
			logger["body"] = string(data)
			fmt.Println("in PUT")
		}
		requestLogger = log.WithFields(logger)
	} else {
		requestLogger = log.WithFields(log.Fields{})
	}

	switch level {
	case "info":
		requestLogger.Info(message)
	case "warn":
		requestLogger.Warn(message)
	case "error":
		requestLogger.Error(message)
	}
}

// Info is use to log error with level info
func Info(c *gin.Context, message string) {
	addLog("info", c, message)
}

// Warn is use to log error with level warn
func Warn(c *gin.Context, message string) {
	addLog("warn", c, message)
}

// Error is use to log error with level error
func Error(c *gin.Context, message string) {
	addLog("error", c, message)
}
