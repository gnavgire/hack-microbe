package config

import (
	"fmt"
	"os"
)

//Default values for environment variables
var (
	HttpPort       = ":8080"
	DBRepoName     = "insightengine"
	DBUserName     = "insightengine"
	DBUserPassword = "admin123"
	DataUploadPath = "/tmp/saamd"
	LogFilePath    = "/tmp/engine.log"
	LogLevel       = "info"
)

// DbConfig structure holds configuration of Database Server
type DbConfig struct {
	Name     string
	User     string
	Password string
}

// LogConfig structure holds configuration of Logging
type LogConfig struct {
	LogFile  string
	LogLevel string
}

// Config structure is the main structure of configuration of server
type Config struct {
	Environment string
	Port        string
	UploadPath  string
	Log         LogConfig
	Database    DbConfig
}

func getEnv(key string, defaultVal string) string {
	if value, exists := os.LookupEnv(key); exists {
		return value
	}
	return defaultVal
}

// GetConfig is use to get current running server config according to environment variable GO_ENV
func GetConfig() Config {
	goEnv := os.Getenv("GO_ENV")
	var configuration Config

	switch goEnv {
	case "production":
		fmt.Println("in production")
		configuration.Environment = "prod"
		configuration.Port = getEnv("Port", HttpPort)
		configuration.Database = DbConfig{Name: os.Getenv("DBName"), User: os.Getenv("DBUser"), Password: os.Getenv("DBPass")}
		configuration.UploadPath = os.Getenv("UploadPath")
		configuration.Log = LogConfig{LogFile: os.Getenv("Logfile"), LogLevel: os.Getenv("LogLevel")}
	case "staging":
		fmt.Println("in staging")
	case "testing":
		fmt.Println("in testing")
	default:
		configuration.Environment = "dev"
		configuration.Port = getEnv("Port", HttpPort)
		configuration.Database = DbConfig{User: getEnv("DBUser", DBUserName), Password: getEnv("DBPass", DBUserPassword), Name: getEnv("DBName", DBRepoName)}
		configuration.UploadPath = getEnv("UploadPath", DataUploadPath)
		configuration.Log = LogConfig{LogFile: getEnv("Logfile", LogFilePath), LogLevel: getEnv("LogLevel", LogLevel)}
	}

	return configuration
}
