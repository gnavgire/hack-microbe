package controllers

import (
	dockercli "SaaMD/middleware/controllers/dockercli"
	log "SaaMD/middleware/log"
	models "SaaMD/middleware/models"
	utils "SaaMD/middleware/utils"
	"bytes"
	"encoding/json"
	"encoding/xml"
	"errors"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/go-pg/pg"
	"io/ioutil"
	"net/http"
	"os"
	"os/exec"
	"strconv"
	"strings"
)

// Parameters struct is use to parse the xml file which we get while adding microservices
type Parameters struct {
	XMLName   xml.Name    `xml:"parameters"`
	Parameter []Parameter `xml:"parameter"`
}

// Parameter struct
type Parameter struct {
	XMLName xml.Name `xml:"parameter"`
	Name    string   `xml:"name,attr"`
	Value   string   `xml:",chardata"`
}

// parse xml file
func parseXML(xmlString string) (*Parameters, error) {
	var parameters Parameters
	err := xml.Unmarshal([]byte(xmlString), &parameters)
	if err != nil {
		return nil, err
	}
	return &parameters, nil
}

// validate xml file and check executable is present or not
func validateService(c *gin.Context, service *models.Service, image *models.Image) bool {

	if service.Type == "executable" {
		// imageId 0 means imageId is not present in request
		// this service containes executable file instead of docker container
		// validate that executable file is present or not
		_, err := os.Stat(service.ExecutableName)
		if err != nil {
			// check executable at $PATH
			_, err := exec.LookPath(service.ExecutableName)
			if err != nil {
				return false
			}
			return true
		}
	} else {
		// validate docker container contains command or not
		// firstly check docker image is present or not
		// run docker file to check if command is present in container or not
		containerID, err := dockercli.RunDockerContainer(*image, service.ExecutableName)
		if err != nil {
			return false
		}

		// this async thread is to stop running container
		go func(id string) {
			_ = dockercli.StopContainer(id)
		}(containerID)
	}
	return true
}

// insert data in database
func addServiceInDatabase(c *gin.Context, service *models.Service) (*models.Service, error) {
	db := c.MustGet("DB").(*pg.DB)
	err := db.Insert(service)
	if err != nil {
		return nil, err
	}
	return service, nil
}

// edit data in database
func editServiceInDatabase(c *gin.Context, service models.Service) {
	db := c.MustGet("DB").(*pg.DB)
	_ = db.Update(&service)
}

//getService is use to get the microservice details from the database
func getService(c *gin.Context, ID string) (*models.Service, error) {
	db := c.MustGet("DB").(*pg.DB)

	Service := new(models.Service)
	err := db.Model(Service).
		Where("service.id = ?", ID).
		Relation("Creator").
		Select()

	return Service, err
}

// if service type is container than add that in image table and validate that, that image is available or not
func addContainerService(c *gin.Context, options map[string]string) (chan bool, int64, error) {
	s := strings.Split(options["ContainerName"], ":")
	if len(s) != 2 {
		return nil, 0, errors.New("Invalid Container Name")
	}

	Name := s[0]
	Version := s[1]

	// create dummy context of request to call add image api
	c, w := utils.CreateTestContext()
	var jsonData = fmt.Sprintf(`{"Name":"%s", "Version": "%s", "RegistryUserName": "%s", "RegistryPassword": "%s"}`, Name, Version, options["RegistryUserName"], options["RegistryPassord"])
	var jsonStr = []byte(jsonData)
	c.Request, _ = http.NewRequest("POST", "", bytes.NewBuffer(jsonStr))
	done := AddImage(c)

	resp := w.Result()
	type Response struct {
		Error   string
		Message string
		Data    map[string]int64
	}
	var response Response
	body, _ := ioutil.ReadAll(resp.Body)
	_ = json.Unmarshal([]byte(string(body)), &response)

	if resp.StatusCode != 200 {
		return nil, 0, errors.New(response.Error)
	}

	return done, response.Data["Id"], nil
}

// AddService is a main handler to add microservices
func AddService(c *gin.Context, testing ...bool) chan bool {

	type ServiceRequest struct {
		EnvironmentID    string
		Type             string
		Name             string
		Description      string
		ExecutableName   string
		InputFilePath    string
		OutputFilePath   string
		ContainerName    string
		RegistryUserName string
		RegistryPassword string
		Parameters       string
	}
	doneServiceExecution := make(chan bool)
	var serviceRequest ServiceRequest

	// checking body is valid json or not
	if err := c.ShouldBindJSON(&serviceRequest); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return doneServiceExecution
	}

	// environment, type, name, description, executablename and parameters are mandatory
	mandatory := []string{"EnvironmentID", "Type", "Name", "Description", "ExecutableName", "Parameters", "InputFilePath", "OutputFilePath"}
	isValid := utils.ValidateRequest(mandatory, &serviceRequest)
	if isValid == false {
		c.JSON(406, gin.H{
			"error": "Missing mandatory parameters",
		})
		return doneServiceExecution
	}

	// validate xml content
	_, err := parseXML(serviceRequest.Parameters)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "Failed to parse file content",
		})
		return doneServiceExecution
	}

	// get session for created by field
	var createdby int64
	if len(testing) == 0 {
		session := utils.GetSession(c)
		createdby, err = strconv.ParseInt(session["UserId"], 10, 64)
	} else {
		createdby = 1
	}

	// convert string environment id to int64 type
	environmentid, err := strconv.ParseInt(serviceRequest.EnvironmentID, 10, 64)

	// create service model with initial status pending
	service := models.Service{
		EnvironmentID:  environmentid,
		Type:           serviceRequest.Type,
		Name:           serviceRequest.Name,
		Description:    serviceRequest.Description,
		ExecutableName: serviceRequest.ExecutableName,
		InputFilePath:  serviceRequest.InputFilePath,
		OutputFilePath: serviceRequest.OutputFilePath,
		Parameters:     serviceRequest.Parameters,
		CreatedBy:      createdby,
		Status:         "pending",
	}
	done := make(chan bool)
	switch serviceRequest.Type {
	case "container":
		// in case of container type we need to add image in image table
		// and also need to validate that image from registry
		options := map[string]string{
			"ContainerName":    serviceRequest.ContainerName,
			"RegistryUserName": serviceRequest.RegistryUserName,
			"RegistryPassword": serviceRequest.RegistryPassword,
		}
		var ImageID int64
		var err error
		done, ImageID, err = addContainerService(c, options)
		if err != nil {
			c.JSON(406, gin.H{
				"error": err.Error(),
			})
			return done
		}
		service.ImageID = ImageID
	case "executable":
		// in case of executable only trigger channel
		// do nothing
	default:
		// invalid service type
		c.JSON(406, gin.H{
			"error": "Invalid Type of Service",
		})
		return doneServiceExecution
	}

	// add data in database with status pending
	Service, err := addServiceInDatabase(c, &service)
	if err != nil {
		// log error in case of error because this is unexpected error
		log.Error(c, err.Error())
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return doneServiceExecution
	}

	c.JSON(200, gin.H{
		"message": "Added Successfully",
	})

	// after channel trigger need to validate executable or container command
	go func(c *gin.Context, service *models.Service) {
		if service.Type == "container" {
			<-done
		}
		var Image *models.Image
		if service.Type == "container" {
			// in case of container type get container image
			// if status of that container image is error that store that error in service also
			Image, err = GetImage(c, service.ImageID)
			if err != nil {
				log.Error(c, "Image Not exists")
				return
			}
			if Image.Status == "error" {
				service.Status = "error"
				service.Error = Image.Error
				editServiceInDatabase(c, *service)
				return
			}
		}

		// validate executable or container command
		isValid := validateService(c, service, Image)

		if isValid == false {
			service.Status = "error"
		} else {
			service.Status = "success"
		}
		editServiceInDatabase(c, *service)
		doneServiceExecution <- true
	}(c, Service)

	return doneServiceExecution
}

// ListService is use to list all microservices which is present in database
func ListService(c *gin.Context) {
	db := c.MustGet("DB").(*pg.DB)

	var service []models.Service

	//Get all entries in ascending order
	err := db.Model(&service).
		Relation("Image").
		Relation("Creator").
		Relation("Environment").
		Order("id ASC").
		Select()

	if err != nil {
		// log error if something unexpected happen while fetching from database
		log.Error(c, err.Error())
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
	} else {
		c.JSON(200, gin.H{
			"data": service})
	}
}

// GetService is use to get the service details
func GetService(c *gin.Context) {
	ID := c.Param("serviceId")
	fmt.Println(ID)
	Service, err := getService(c, ID)
	if err != nil {
		log.Error(c, err.Error())
		c.JSON(404, gin.H{"error": err.Error()})
		return
	}

	c.JSON(200, gin.H{
		"data": Service})
}

//DeleteService is use to soft delete the microservices
func DeleteService(c *gin.Context) {
	ID := c.Param("serviceId")
	Service, err := getService(c, ID)
	if err != nil {
		log.Error(c, err.Error())
		c.JSON(404, gin.H{"error": err.Error()})
		return
	}

	if Service.Type == "container" {
		err := DeleteImage(c, Service.ImageID)
		if err != nil {
			c.JSON(404, gin.H{"error": err.Error()})
			return
		}
	}

	Service.IsDisable = true

	editServiceInDatabase(c, *Service)
	c.JSON(200, gin.H{
		"message": "Deleted Successfully"})
}
