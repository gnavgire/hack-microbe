package controllers

// import (
// 	database "SaaMD/middleware/database"
// 	// models "SaaMD/middleware/models"
// 	utils "SaaMD/middleware/utils"
// 	"bytes"
// 	// "encoding/json"
// 	"github.com/stretchr/testify/assert"
// 	// "io/ioutil"
// 	"net/http"
// 	"testing"
// )

// func TestUserSignUp(t *testing.T) {
// 	c, w := utils.CreateTestContext()

// 	var jsonStr = []byte(`{
// 		"UserName":"nitesh", 
// 		"Password": "123",
// 		"FirstName": "Nitesh",
// 		"LastName": "Jain",
// 		"Email": "nitesh2.jain@aricent.com"
// 	}`)
// 	c.Request, _ = http.NewRequest("POST", "http://localhost:8080/api/v1/users/sign-up", bytes.NewBuffer(jsonStr))

// 	UserSignUp(c)
// 	resp := w.Result()

// 	assert.Equal(t, 200, resp.StatusCode, "Error while Register User")

// 	users, err := ListUsers(c)

// 	if err != nil {
// 		t.Errorf("Error while getting user data")
// 		return
// 	}

// 	assert.Equal(t, "nitesh", users[0].UserName, "Sign up username and list usernames are different")
// }

// func TestSignIn(t *testing.T) {
// 	defer database.DropTables()

// 	c, w := utils.CreateTestContext()

// 	var jsonStr = []byte(`{
// 		"UserName":"nitesh", 
// 		"Password": "123"
// 	}`)
// 	c.Request, _ = http.NewRequest("POST", "http://localhost:8080/api/v1/users/sign-in", bytes.NewBuffer(jsonStr))

// 	UserSignIn(c)
// 	resp := w.Result()
// 	assert.Equal(t, 200, resp.StatusCode, "Error while Login User")
// }
