package controllers

import (
	dockercli "SaaMD/middleware/controllers/dockercli"
	log "SaaMD/middleware/log"
	models "SaaMD/middleware/models"
	utils "SaaMD/middleware/utils"
	"errors"
	"github.com/gin-gonic/gin"
	"github.com/go-pg/pg"
	"net/http"
)

// insert data in database
func addImageInDatabase(c *gin.Context, image models.Image) (*models.Image, error) {
	db := c.MustGet("DB").(*pg.DB)

	Image := &models.Image{
		Name:    image.Name,
		Version: image.Version,
		Status:  "pending",
	}

	// both username and password required for authentication
	// TODO: confirm with Ganesh that we need to give error when anyone from RegistryUserName or RegistryUserPassword is present
	if image.RegistryUserName != "" && image.RegistryUserPassword != "" {
		Image.RegistryUserName = image.RegistryUserName
		Image.RegistryUserPassword = image.RegistryUserPassword
	}

	Error := db.Insert(Image)
	return Image, Error
}

// pull docker image with or without authenticatication
func pullDockerImage(image models.Image) error {
	var err error
	if image.RegistryUserName != "" && image.RegistryUserPassword != "" {
		// if username and password exists then call authentication module
		err = dockercli.PullAuthentication(image)
	} else {
		// without authentication pull image
		err = dockercli.Pull(image)
	}

	return err
}

// check docker image in database exists or not
func checkImageExists(c *gin.Context, image models.Image) error {
	db := c.MustGet("DB").(*pg.DB)
	Image := new(models.Image)
	err := db.Model(Image).
		Where("name = ?", image.Name).
		Where("version = ?", image.Version).
		Where("status = ?", "success").
		Select()

	if err == nil {
		return errors.New("Container Image Already Exists")
	}

	return nil
}

// Edit database with help of primary key i.e Id
func editImageInDatabase(c *gin.Context, image models.Image) {
	db := c.MustGet("DB").(*pg.DB)
	_ = db.Update(&image)
}

// AddImage is use to pull image from registry and add image data in database
func AddImage(c *gin.Context) chan bool {
	var image models.Image
	done := make(chan bool)
	// checking body is valid json or not
	if err := c.ShouldBindJSON(&image); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return done
	}

	// validate mandatory parameters
	mandatory := []string{"Name", "Version"}
	isValid := utils.ValidateRequest(mandatory, &image)
	if isValid == false {
		c.JSON(406, gin.H{
			"error": "Missing mandatory parameters",
		})
		return done
	}

	var err error

	// check docker image already exists
	err = checkImageExists(c, image)
	if err != nil {
		c.JSON(406, gin.H{"error": err.Error()})
		return done
	}

	// add image data in database
	var Image *models.Image
	Image, err = addImageInDatabase(c, image)
	if err != nil {
		// if something went wrong adding in database
		log.Error(c, err.Error())
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return done
	}

	// success status if everything works fine
	c.JSON(200, gin.H{
		"message": "Added Successfully",
		"data": map[string]int64{
			"Id": Image.ID,
		},
	})

	// pull docker image whether from dockerhub or from local docker registry async
	go func(c *gin.Context, image *models.Image) {
		err = pullDockerImage(*image)
		if err != nil {
			log.Error(c, err.Error())
			// if error then add errored status in database
			image.Status = "error"
			image.Error = err.Error()
			editImageInDatabase(c, *image)
		} else {
			image.Status = "success"
			editImageInDatabase(c, *image)
		}
		done <- true
	}(c, Image)

	return done
}

// ListImage is use to list all the microservice container images
func ListImage(c *gin.Context) {
	db := c.MustGet("DB").(*pg.DB)

	var image []models.Image

	//Get all entries in ascending order
	err := db.Model(&image).Order("id ASC").Select()

	if err != nil {
		// log error if something unexpected happen while fetching from database
		log.Error(c, err.Error())
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
	} else {
		c.JSON(200, gin.H{
			"data": image})
	}
}

// GetImage is use to get the container image by database id
func GetImage(c *gin.Context, ID int64) (*models.Image, error) {
	db := c.MustGet("DB").(*pg.DB)
	Image := new(models.Image)
	err := db.Model(Image).
		Where("id = ?", ID).
		Select()

	if err != nil {
		return nil, err
	}
	return Image, nil
}

// DeleteImage is use to set isDisable in database
func DeleteImage(c *gin.Context, ID int64) error {
	Image, err := GetImage(c, ID)

	if err != nil {
		return err
	}

	Image.IsDisable = true
	editImageInDatabase(c, *Image)

	return nil
}
