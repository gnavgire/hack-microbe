package controllers

import (
	config "SaaMD/middleware/config"
	log "SaaMD/middleware/log"
	models "SaaMD/middleware/models"
	utils "SaaMD/middleware/utils"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/go-pg/pg"
	"net/http"
	"os"
	"path"
	"path/filepath"
	"regexp"
	"strconv"
)

//NewDatasource is a handler function for upload entry point of datasource
func NewDatasource(c *gin.Context) {
	//file type, username and actual file are the mandatory parameters
	filetype := c.PostForm("type")
	dsname := c.PostForm("name")
	dsdesc := c.PostForm("description")
	file, err := c.FormFile("file")
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Failed to parse file content"})
		return
	}

	//validate extension of the uploaded file
	ext := filepath.Ext(file.Filename)
	if !isExtensionAllowed(ext) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Unsupported file extension"})
		return
	}

	session := utils.GetSession(c)

	//create sub dir in user configured dir for saving datasources
	subDir := fmt.Sprintf("user_%s", session["UserName"])
	cfg := config.GetConfig()
	uploadsDir := path.Join(cfg.UploadPath, subDir)
	uploadPath := uploadsDir + "/" + file.Filename

	if err := os.MkdirAll(uploadsDir, 0755); err != nil {
		//complain if we dont have permisions
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// get session for created by field
	var createdby int64
	createdby, err = strconv.ParseInt(session["UserId"], 10, 64)

	//Populate ds parameters
	dsp := models.Datasource{
		Name:        dsname,
		Description: dsdesc,
		Type:        filetype,
		Path:        uploadPath,
		CreatedBy:   createdby,
	}

	//Check for mandatory parameters
	mandatory := []string{"Name", "Description", "Type"}
	isValid := utils.ValidateRequest(mandatory, &dsp)
	if isValid == false {
		c.JSON(406, gin.H{
			"error": "Missing mandatory parameters",
		})
		return
	}

	//download the file to the destination
	if err := c.SaveUploadedFile(file, path.Join(uploadsDir, file.Filename)); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	//create the entry for datasource in the DB
	err = addDatasource(dsp, c)
	if err != nil {
		c.JSON(406, gin.H{
			"error": err.Error(),
		})
		return
	}

	c.JSON(200, gin.H{
		"message": "Datasource Upload Successfully",
	})
}

//Create entry for datasource in DB
func addDatasource(dsp models.Datasource, c *gin.Context) error {
	db := c.MustGet("DB").(*pg.DB)

	log.Info(c, "Creating new datasource entry ")
	dsentry := &models.Datasource{
		Name:        dsp.Name,
		Description: dsp.Description,
		Type:        dsp.Type,
		Path:        dsp.Path,
		CreatedBy:   dsp.CreatedBy,
	}
	err := db.Insert(dsentry)

	return err
}

func isExtensionAllowed(fileExt string) bool {
	//xml and fastq are valid extensions, more can be added
	validExtPattern := "(?i)^\\.xml|\\.fastq" //(?i) == case insensitive
	if matched, _ := regexp.MatchString(validExtPattern, fileExt); matched {
		return true
	}
	return false
}

//get Datasource is used to get the datasource using ID from database
func getDatasource(c *gin.Context, ID string) (*models.Datasource, error) {
	db := c.MustGet("DB").(*pg.DB)

	Datasource := new(models.Datasource)
	err := db.Model(Datasource).
		Where("id = ?", ID).
		Select()

	return Datasource, err
}

//ListDatasource is a handler function for enumerating datasource
func ListDatasource(c *gin.Context) {
	db := c.MustGet("DB").(*pg.DB)
	var ds []models.Datasource
	//Get all entries in ascending order
	err := db.Model(&ds).
		Relation("Creator").
		Order("id ASC").
		Select()

	if err != nil {
		c.JSON(506, gin.H{
			"error":     "Could not query DB",
			"error_msg": err,
		})
		return
	}
	c.JSON(200, gin.H{
		"datasource": ds})
}
