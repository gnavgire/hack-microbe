package dockercli

import (
	log "SaaMD/middleware/log"
	models "SaaMD/middleware/models"
	"encoding/base64"
	"encoding/json"
	"github.com/docker/docker/api/types"
	"github.com/docker/docker/api/types/container"
	"github.com/docker/docker/client"
	"golang.org/x/net/context"
	"io"
	"os"
	"strings"
)

func initDocker() (context.Context, *client.Client, error) {
	ctx := context.Background()
	cli, err := client.NewClientWithOpts(client.FromEnv, client.WithAPIVersionNegotiation())

	if err != nil {
		log.Error(nil, err.Error())
		return nil, nil, err
	}
	return ctx, cli, nil
}

// Pull docker image without authentication
func Pull(image models.Image) error {
	ctx, cli, err := initDocker()
	if err != nil {
		return err
	}

	out, err := cli.ImagePull(ctx, image.Name+":"+image.Version, types.ImagePullOptions{})

	if err != nil {
		return err
	}

	defer out.Close()

	io.Copy(os.Stdout, out)
	return nil
}

// PullAuthentication is use to pull docker image with authentication
func PullAuthentication(image models.Image) error {
	ctx, cli, err := initDocker()
	if err != nil {
		return err
	}

	authConfig := types.AuthConfig{
		Username: image.RegistryUserName,
		Password: image.RegistryUserPassword,
	}
	encodedJSON, err := json.Marshal(authConfig)
	if err != nil {
		return err
	}

	authStr := base64.URLEncoding.EncodeToString(encodedJSON)

	out, err := cli.ImagePull(ctx, image.Name+":"+image.Version, types.ImagePullOptions{RegistryAuth: authStr})
	if err != nil {
		return err
	}

	defer out.Close()
	io.Copy(os.Stdout, out)

	return nil
}

// RunDockerContainer is use to run the docker container image
func RunDockerContainer(image models.Image, command string) (string, error) {
	ctx, cli, err := initDocker()
	if err != nil {
		return "", err
	}

	resp, _ := cli.ContainerCreate(ctx, &container.Config{
		Image: image.Name,
		Cmd:   []string{command},
		Tty:   true,
	}, &container.HostConfig{
		AutoRemove: true,
	}, nil, "")

	err = cli.ContainerStart(ctx, resp.ID, types.ContainerStartOptions{})

	return resp.ID, err
}

// StopContainer is use to stop the running container image
func StopContainer(id string) error {
	ctx, cli, err := initDocker()
	if err != nil {
		return err
	}

	err = cli.ContainerStop(ctx, id, nil)
	if err != nil {
		return err
	}

	return nil
}

// ListContainerImages is use to list all the container image
func ListContainerImages() []types.ImageSummary {
	cli, err := client.NewClientWithOpts(client.FromEnv, client.WithAPIVersionNegotiation())
	if err != nil {
		panic(err)
	}

	images, err := cli.ImageList(context.Background(), types.ImageListOptions{})
	if err != nil {
		panic(err)
	}

	return images
}

// CheckContainerImages is use to check docker image is exists or not
// this function only return boolean end
func CheckContainerImages(repository string) bool {
	images := ListContainerImages()

	isExists := false
	for _, image := range images {
		tag := image.RepoTags[0]
		isExists = strings.Contains(tag, repository)
		if isExists == true {
			break
		}
	}

	return isExists
}
