package controllers

import (
	log "SaaMD/middleware/log"
	models "SaaMD/middleware/models"
	utils "SaaMD/middleware/utils"
	"encoding/xml"
	"github.com/gin-gonic/gin"
	"github.com/go-pg/pg"
	"net/http"
	"strconv"
)

// Definition struct is use to parse the xml file which we get while adding pipeline
type Definition struct {
	XMLName xml.Name `xml:"definitions"`
	Process Process  `xml:"process"`
}

// Process struct for pipeline related parameters
type Process struct {
	XMLName     xml.Name      `xml:"process"`
	InputTask   InputTask     `xml:"inputTask"`
	ServiceTask []ServiceTask `xml:"serviceTask"`
	ScriptTask  []ScriptTask  `xml:"scriptTask"`
}

// ScriptTask struct for pipeline related parameters
type ScriptTask struct {
	XMLName   xml.Name `xml:"scriptTask"`
	ServiceID string   `xml:"serviceid,attr"`
}

// ServiceTask struct for pipeline related parameters
type ServiceTask struct {
	XMLName   xml.Name `xml:"serviceTask"`
	ServiceID string   `xml:"serviceid,attr"`
}

// InputTask struct for pipeline related parameters
type InputTask struct {
	XMLName      xml.Name `xml:"inputTask"`
	DatasourceID string   `xml:"datasourceid,attr"`
}

// parse xml file
func parsePipelineXML(xmlString string) (*Definition, error) {
	var def Definition
	err := xml.Unmarshal([]byte(xmlString), &def)
	if err != nil {
		return nil, err
	}
	return &def, nil
}

// insert data in database
func addPipelineInDatabase(c *gin.Context, pipe *models.Pipeline) (*models.Pipeline, error) {
	db := c.MustGet("DB").(*pg.DB)
	err := db.Insert(pipe)
	if err != nil {
		return nil, err
	}
	return pipe, nil
}

// edit data in database
func editPipelineInDatabase(c *gin.Context, pipeline models.Pipeline) {
	db := c.MustGet("DB").(*pg.DB)
	_ = db.Update(&pipeline)
}

// updatePipeline is use to update the pipeline in the database
func updatePipeline(c *gin.Context, pl models.Pipeline) {
	db := c.MustGet("DB").(*pg.DB)
	_ = db.Update(&pl)
}

// AddPipeline is a main handler to add pipelines
func AddPipeline(c *gin.Context, testing ...bool) {
	var pipe models.Pipeline
	var createdby int64

	// checking body is valid json or not
	if err := c.ShouldBindJSON(&pipe); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Name, Description, Version and Definition are mandatory parameters
	mandatory := []string{"Name", "Description", "Version", "Definition"}
	isValid := utils.ValidateRequest(mandatory, &pipe)
	if !isValid {
		c.JSON(406, gin.H{
			"error": "Missing mandatory parameters",
		})
		return
	}

	// validate xml content
	def, err := parsePipelineXML(pipe.Definition)

	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "Failed to parse file content",
		})
		return
	}

	// get session for created by field
	if len(testing) == 0 {
		session := utils.GetSession(c)
		createdby, _ = strconv.ParseInt(session["UserId"], 10, 64)
	} else {
		createdby = 1
	}

	// create service model with initial status pending
	pl := models.Pipeline{
		Name:        pipe.Name,
		Description: pipe.Description,
		Version:     pipe.Version,
		Definition:  pipe.Definition,
		CreatedBy:   createdby,
		Status:      "pending",
	}

	// add data in database with status pending
	Pipeline, err := addPipelineInDatabase(c, &pl)
	if err != nil {
		// log error in case of error because this is unexpected error
		log.Error(c, err.Error())
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	c.JSON(200, gin.H{
		"data": map[string]int64{
			"Id": Pipeline.ID,
		},
		"message": "Added Successfully",
	})

	go func(c *gin.Context, def *Definition, pl models.Pipeline) {
		DatasourceID := def.Process.InputTask.DatasourceID

		var isValid bool

		_, err := getDatasource(c, DatasourceID)

		if err != nil {
			isValid = false
			pl.Status = "error"
			pl.Error = "Datasource is invalid"
			updatePipeline(c, pl)
		}

		ServiceTasks := def.Process.ServiceTask
		for i := 0; i < len(ServiceTasks); i++ {
			id := ServiceTasks[i].ServiceID
			_, err := getService(c, id)
			if err != nil {
				isValid = false
				pl.Status = "error"
				pl.Error = "Service " + id + " is invalid"
				updatePipeline(c, pl)
				break
			}
		}

		if isValid {
			ScriptTask := def.Process.ScriptTask
			for i := 0; i < len(ScriptTask); i++ {
				id := ScriptTask[i].ServiceID
				_, err := getService(c, id)
				if err != nil {
					isValid = false
					pl.Status = "error"
					pl.Error = "Service " + id + " is invalid"
					updatePipeline(c, pl)
					break
				}
			}
		}

		if isValid {
			pl.Status = "success"
			updatePipeline(c, pl)
		}
	}(c, def, pl)
}

// ListPipeline is use to list all pipelines which is present in database
func ListPipeline(c *gin.Context) {
	db := c.MustGet("DB").(*pg.DB)

	var pipeline []models.Pipeline

	//Get all entries in ascending order
	err := db.Model(&pipeline).
		Relation("Creator").
		Order("id ASC").
		Select()

	if err != nil {
		// log error if something unexpected happen while fetching from database
		log.Error(c, err.Error())
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
	} else {
		c.JSON(200, gin.H{
			"data": pipeline})
	}
}

//GetPipeline is use to get indiviual pipeline data according to primary key
func GetPipeline(c *gin.Context) {
	db := c.MustGet("DB").(*pg.DB)

	ID := c.Param("pipelineId")
	Pipeline := new(models.Pipeline)
	err := db.Model(Pipeline).
		Where("pipeline.id = ?", ID).
		Relation("Creator").
		Select()

	if err != nil {
		log.Error(c, err.Error())
		c.JSON(404, gin.H{"error": err.Error()})
		return
	}

	c.JSON(200, gin.H{
		"data": Pipeline})
}

//ExecutePipeline is use to get indiviual pipeline data according to primary key
/*
func ExecutePipeline(c *gin.Context) {
	db := c.MustGet("DB").(*pg.DB)
}
*/
