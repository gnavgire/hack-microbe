package controllers

import (
	log "SaaMD/middleware/log"
	models "SaaMD/middleware/models"
	utils "SaaMD/middleware/utils"
	"github.com/gin-gonic/gin"
	"github.com/go-pg/pg"
	"golang.org/x/crypto/bcrypt"
	"net/http"
	"strconv"
	"time"
)

func getUser(username string, c *gin.Context) *models.User {
	db := c.MustGet("DB").(*pg.DB)
	user := new(models.User)
	err := db.Model(user).
		Where("user_name = ?", username).
		Select()

	if err != nil {
		return nil
	}

	return user
}

func addUser(user models.User, c *gin.Context) error {
	db := c.MustGet("DB").(*pg.DB)
	user1 := &models.User{
		UserName:  user.UserName,
		Email:     user.Email,
		Password:  user.Password,
		FirstName: user.FirstName,
		LastName:  user.LastName,
	}
	err := db.Insert(user1)

	return err
}

func hashAndSalt(pwd []byte) (string, error) {
	hash, err := bcrypt.GenerateFromPassword(pwd, bcrypt.MinCost)
	if err != nil {
		return "", err
	}

	return string(hash), nil
}

func comparePassword(hashedPassword, password []byte) bool {
	err := bcrypt.CompareHashAndPassword(hashedPassword, password)
	if err == nil {
		return true
	}
	return false
}

// UserSignIn handler is use to login the user and create session based on cookie
func UserSignIn(c *gin.Context) {
	var loginUser models.User

	if err := c.ShouldBindJSON(&loginUser); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	mandatory := []string{"UserName", "Password"}
	isValid := utils.ValidateRequest(mandatory, &loginUser)
	if isValid == false {
		c.JSON(406, gin.H{
			"error": "User Name and Password is required",
		})
		return
	}

	user := getUser(loginUser.UserName, c)
	if user == nil {
		c.JSON(406, gin.H{
			"error": "Invalid User Name",
		})
		return
	}

	isPasswordValid := comparePassword([]byte(user.Password), []byte(loginUser.Password))
	if isPasswordValid == false {
		c.JSON(406, gin.H{
			"error": "Invalid Password",
		})
		return
	}

	t := time.Now()

	utils.SaveSession(c, map[string]string{
		"isLoggedIn":     "true",
		"UserName":       user.UserName,
		"UserId":         strconv.FormatInt(user.ID, 10),
		"last_logged_in": t.String(),
	})

	c.JSON(200, gin.H{
		"message": "LoggedIn Successfully",
	})
}

// UserSignUp is use to register new user
func UserSignUp(c *gin.Context) {
	var user models.User

	if err := c.ShouldBindJSON(&user); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	mandatory := []string{"UserName", "Password", "FirstName", "LastName", "Email"}
	isValid := utils.ValidateRequest(mandatory, &user)
	if isValid == false {
		c.JSON(406, gin.H{
			"error": "Missing mandatory parameters",
		})
		return
	}

	user1 := getUser(user.UserName, c)
	if user1 != nil {
		c.JSON(406, gin.H{
			"error": "User Name already exists",
		})
		return
	}

	var err error

	user.Password, err = hashAndSalt([]byte(user.Password))
	if err != nil {
		c.JSON(406, gin.H{
			"error": err.Error(),
		})
		return
	}

	err = addUser(user, c)
	if err != nil {
		c.JSON(406, gin.H{
			"error": err.Error(),
		})
		return
	}

	c.JSON(200, gin.H{
		"message": "Registered Successfully",
	})
}

// UserSession handler is use to get the user session
func UserSession(c *gin.Context) {
	user := utils.GetSession(c)
	c.JSON(200, gin.H{
		"user": user,
	})
}

// UserSignOut is use to set IsLoggedIn false in user session
func UserSignOut(c *gin.Context) {
	utils.SaveSession(c, map[string]string{
		"isLoggedIn": "false",
	})
	c.JSON(200, gin.H{
		"message": "Log Out Successfully",
	})
}

// ListUsers is use to list all user present in database
func ListUsers(c *gin.Context) ([]models.User, error) {
	db := c.MustGet("DB").(*pg.DB)

	var users []models.User

	//Get all entries in ascending order
	err := db.Model(&users).Order("id ASC").Select()

	if err != nil {
		// log error if something unexpected happen while fetching from database
		log.Error(c, err.Error())
		return nil, err
	}
	return users, nil
}
