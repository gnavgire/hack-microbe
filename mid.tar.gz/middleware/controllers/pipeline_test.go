package controllers

import (
	database "SaaMD/middleware/database"
	utils "SaaMD/middleware/utils"
	"bytes"
	"fmt"
	"net/http"
	"reflect"
	"testing"
)

func TestAddPipelineHandler(t *testing.T) {
	// after task complete we need to drop all the tables
	defer database.DropTables()

	//declare request bodies
	var simpletest = []byte(`{ "Name": "testpipe1", "DatasourceId": 1, "Version": "1.0", "Description": "testpipeline def", "Definition": "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<bpmn:definitions xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:bpmn=\"http://www.omg.org/spec/BPMN/20100524/MODEL\" xmlns:bpmndi=\"http://www.omg.org/spec/BPMN/20100524/DI\" xmlns:dc=\"http://www.omg.org/spec/DD/20100524/DC\" xmlns:di=\"http://www.omg.org/spec/DD/20100524/DI\" id=\"Definitions_1\" targetNamespace=\"http://bpmn.io/schema/bpmn\"><bpmn:process id=\"Process_1\" isExecutable=\"false\"><bpmn:startEvent id=\"StartEvent_1\"><bpmn:outgoing>SequenceFlow_033plhq</bpmn:outgoing></bpmn:startEvent><bpmn:sequenceFlow id=\"SequenceFlow_033plhq\" sourceRef=\"StartEvent_1\" targetRef=\"Task_08m3qhn\" /><bpmn:inputTask id=\"Task_08m3qhn\" name=\"Datasource_1\" datasourceid=\"1\" filepath=\"/tmp/saamd/user_admin\" type=\"xml\" description=\"some datasource\"><bpmn:incoming>SequenceFlow_033plhq</bpmn:incoming><bpmn:outgoing>SequenceFlow_1x6qc04</bpmn:outgoing></bpmn:inputTask><bpmn:sequenceFlow id=\"SequenceFlow_1x6qc04\" sourceRef=\"Task_08m3qhn\" targetRef=\"Task_0iwzz6e\" /><bpmn:serviceTask id=\"Task_0iwzz6e\" name=\"Service_1\" serviceid=\"1\" executablename=\"docker\" containername=\"\" type=\"executable\" description=\"some service\"><bpmn:incoming>SequenceFlow_1x6qc04</bpmn:incoming><bpmn:outgoing>SequenceFlow_15dovel</bpmn:outgoing></bpmn:serviceTask><bpmn:endEvent id=\"EndEvent_0l0wmlx\"><bpmn:incoming>SequenceFlow_15dovel</bpmn:incoming></bpmn:endEvent><bpmn:sequenceFlow id=\"SequenceFlow_15dovel\" sourceRef=\"Task_0iwzz6e\" targetRef=\"EndEvent_0l0wmlx\" /></bpmn:process><bpmndi:BPMNDiagram id=\"BPMNDiagram_1\"><bpmndi:BPMNPlane id=\"BPMNPlane_1\" bpmnElement=\"Process_1\"><bpmndi:BPMNShape id=\"_BPMNShape_StartEvent_2\" bpmnElement=\"StartEvent_1\"><dc:Bounds x=\"173\" y=\"102\" width=\"36\" height=\"36\" /></bpmndi:BPMNShape><bpmndi:BPMNEdge id=\"SequenceFlow_033plhq_di\" bpmnElement=\"SequenceFlow_033plhq\"><di:waypoint x=\"209\" y=\"120\" /><di:waypoint x=\"259\" y=\"120\" /></bpmndi:BPMNEdge><bpmndi:BPMNShape id=\"InputTask_1sv3lkq_di\" bpmnElement=\"Task_08m3qhn\"><dc:Bounds x=\"259\" y=\"80\" width=\"100\" height=\"80\" /></bpmndi:BPMNShape><bpmndi:BPMNEdge id=\"SequenceFlow_1x6qc04_di\" bpmnElement=\"SequenceFlow_1x6qc04\"><di:waypoint x=\"359\" y=\"120\" /><di:waypoint x=\"409\" y=\"120\" /></bpmndi:BPMNEdge><bpmndi:BPMNShape id=\"ServiceTask_0m1pzri_di\" bpmnElement=\"Task_0iwzz6e\"><dc:Bounds x=\"409\" y=\"80\" width=\"100\" height=\"80\" /></bpmndi:BPMNShape><bpmndi:BPMNShape id=\"EndEvent_0l0wmlx_di\" bpmnElement=\"EndEvent_0l0wmlx\"><dc:Bounds x=\"559\" y=\"102\" width=\"36\" height=\"36\" /></bpmndi:BPMNShape><bpmndi:BPMNEdge id=\"SequenceFlow_15dovel_di\" bpmnElement=\"SequenceFlow_15dovel\"><di:waypoint x=\"509\" y=\"120\" /><di:waypoint x=\"559\"y=\"120\" /></bpmndi:BPMNEdge></bpmndi:BPMNPlane></bpmndi:BPMNDiagram></bpmn:definitions>" }`)
	var lowercase = []byte(`{ "name": "testpipe2", "datasourceid": 2, "version": "1.0", "description": "testpipeline with lowercase", "definition": "<?xml version='1.0' encoding='UTF-8'?><bpmn:definition><bpmn:pipeline name='fp1'><bpmn:Service name='serv1'><bpmn:executable_name>demolnk.exe</bpmn:executable_name><bpmn:input>input2.xml</bpmn:input><bpmn:output>step1.xml</bpmn:output></bpmn:Service><bpmn:Service name='serv2'><bpmn:executable_name>lnk2.exe</bpmn:executable_name><bpmn:input>step1.xml</bpmn:input><bpmn:output>step2.xml</bpmn:output></bpmn:Service></bpmn:pipeline></bpmn:definition>" }`)
	var parseXMLError = []byte(`{ "name": "testpipe2", "datasourceid": 2, "version": "1.0", "description": "testpipeline with lowercase", "definition": "<?xml version='1.0' encoding='UTF-8'?><bpmn:definition><bpmn:pipeline name='fp1'><bpmn:Service name='serv1'><bpmn:executable_name>demolnk.exe</bpmn:executable_name><bpmn:input>input2.xml</bpmn:input><bpmn:output>step1.xml</bpmn:output><bpmn:Service name='serv2'><bpmn:executable_name>lnk2.exe</bpmn:executable_name><bpmn:input>step1.xml</bpmn:input><bpmn:output>step2.xml</bpmn:output></bpmn:Service></bpmn:pipeline></bpmn:definition>" }`)
	var mandatoryParamName = []byte(`{ "datasourceid": 2, "version": "1.0", "description": "testpipeline with lowercase", "definition": "<?xml version='1.0' encoding='UTF-8'?><bpmn:definition><bpmn:pipeline name='fp1'><bpmn:Service name='serv1'><bpmn:executable_name>demolnk.exe</bpmn:executable_name><bpmn:input>input2.xml</bpmn:input><bpmn:output>step1.xml</bpmn:output></bpmn:Service><bpmn:Service name='serv2'><bpmn:executable_name>lnk2.exe</bpmn:executable_name><bpmn:input>step1.xml</bpmn:input><bpmn:output>step2.xml</bpmn:output></bpmn:Service></bpmn:pipeline></bpmn:definition>" }`)
	var mandatoryParamDef = []byte(`{ "name": "testpipe2", "datasourceid": 2, "version": "1.0", "description": "testpipeline with lowercase"}  }`)
	var invalidPost = []byte(`{ "testpipe1", "DatasourceId": 1, "Version": "1.0", "Description": "testpipeline def", "Definition": "<?xml version='1.0' encoding='UTF-8'?><bpmn:definition><bpmn:pipeline name='fp2'><bpmn:Service name='serv9'><bpmn:executable_name>demolnk.exe</bpmn:executable_name><bpmn:input>input2.xml</bpmn:input><bpmn:output>step1.xml</bpmn:output></bpmn:Service></bpmn:pipeline></bpmn:definition>" }`)
	var largePipe = []byte(`{ "name": "largepipe", "datasourceid": 7, "version": "1.1", "description": "testpipeline with large definition", "definition": "<?xml version='1.0' encoding='UTF-8'?><bpmn:definition><bpmn:pipeline name='fp1'><bpmn:Service name='servA'><bpmn:executable_name>demo.exe</bpmn:executable_name><bpmn:input>input2.xml</bpmn:input><bpmn:output>step1.xml</bpmn:output></bpmn:Service><bpmn:Service name='servB'><bpmn:executable_name>foo.exe</bpmn:executable_name><bpmn:input>step1.xml</bpmn:input><bpmn:output>step2.xml</bpmn:output></bpmn:Service><bpmn:Service name='servC'><bpmn:executable_name>baz.exe</bpmn:executable_name><bpmn:input>step2.xml</bpmn:input><bpmn:output>step3.xml</bpmn:output></bpmn:Service><bpmn:Service name='servD'><bpmn:executable_name>tic.exe</bpmn:executable_name><bpmn:input>step3.xml</bpmn:input><bpmn:output>step4.xml</bpmn:output></bpmn:Service><bpmn:Service name='servE'><bpmn:executable_name>tac.exe</bpmn:executable_name><bpmn:input>step4.xml</bpmn:input><bpmn:output>step5.xml</bpmn:output></bpmn:Service><bpmn:Service name='servF'><bpmn:executable_name>lsl.exe</bpmn:executable_name><bpmn:input>step5.xml</bpmn:input><bpmn:output>step6.xml</bpmn:output></bpmn:Service><bpmn:Service name='servG'><bpmn:executable_name>gazz.exe</bpmn:executable_name><bpmn:input>step6.xml</bpmn:input><bpmn:output>step7.xml</bpmn:output></bpmn:Service></bpmn:pipeline></bpmn:definition>" }`)

	tests := map[string]struct {
		input []byte
		want  int
	}{
		"SimpleAdd":         {input: simpletest, want: 200},
		"LowerCaseAdd":      {input: lowercase, want: 200},
		"ParseXmlError":     {input: parseXMLError, want: 400},
		"NameMissing":       {input: mandatoryParamName, want: 406},
		"DefinitionMissing": {input: mandatoryParamDef, want: 406},
		"InvalidRequest":    {input: invalidPost, want: 400},
		"ComplexAdd":        {input: largePipe, want: 200},
	}

	//Loop to execute the Test Cases
	for name, tc := range tests {
		c, w := utils.CreateTestContext()
		fmt.Println("Executing TestCase", name)
		c.Request, _ = http.NewRequest("POST", "/api/v1/pipeline/add", bytes.NewBuffer(tc.input))
		// add and verify pipeline in database
		AddPipeline(c, true)
		resp := w.Result()
		if !reflect.DeepEqual(tc.want, resp.StatusCode) {
			t.Fatalf("%s: expected: %v, got: %v", name, tc.want, resp.StatusCode)
		}
	}
}
