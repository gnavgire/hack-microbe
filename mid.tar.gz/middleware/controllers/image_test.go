package controllers

import (
	dockercli "SaaMD/middleware/controllers/dockercli"
	database "SaaMD/middleware/database"
	models "SaaMD/middleware/models"
	utils "SaaMD/middleware/utils"
	"bytes"
	"encoding/json"
	"github.com/stretchr/testify/assert"
	"io/ioutil"
	"net/http"
	"testing"
)

type responseObj struct {
	Data []models.Image `json:"data"`
}

func TestAddAndListImageSuccess(t *testing.T) {
	// after task complete we need to drop all the tables
	defer database.DropTables()
	c, w := utils.CreateTestContext()

	var jsonStr = []byte(`{"Name":"localhost:5000/my-ubuntu", "Version": "latest"}`)
	c.Request, _ = http.NewRequest("POST", "http://localhost:8080/api/v1/container-images/add", bytes.NewBuffer(jsonStr))

	// add and verify image in database
	done := AddImage(c)
	resp := w.Result()
	type Response struct {
		Error   string
		Message string
		Data    map[string]int64
	}
	var response Response
	body, _ := ioutil.ReadAll(resp.Body)
	_ = json.Unmarshal([]byte(string(body)), &response)
	// define channel done to wait for goroutine to complete
	<-done

	// create new context for list images
	c, w = utils.CreateTestContext()

	// list image
	ListImage(c)
	var response1 responseObj
	resp = w.Result()
	body, _ = ioutil.ReadAll(resp.Body)
	_ = json.Unmarshal([]byte(string(body)), &response1)

	data := response1.Data[0]

	// if status is other than success this will give error
	assert.Equal(t, "success", data.Status, "Error while adding Container image")

	// check image exists in docker
	isExists := dockercli.CheckContainerImages("localhost:5000/my-ubuntu")
	assert.Equal(t, true, isExists, "Container Images is not exists in docker container")
}
