package controllers

import (
	dockercli "SaaMD/middleware/controllers/dockercli"
	database "SaaMD/middleware/database"
	utils "SaaMD/middleware/utils"
	"bytes"
	"encoding/json"
	"github.com/stretchr/testify/assert"
	"io/ioutil"
	"net/http"
	"testing"
)

func TestAddAndListServiceSuccess(t *testing.T) {
	// after task complete we need to drop all the tables
	defer database.DropTables()
	c, w := utils.CreateTestContext()

	var jsonStr = []byte(`{
		"Name": "test", 
		"EnvironmentId": "1",
		"Type": "container",
		"ExecutableName": "pwd",
		"ContainerName": "ubuntu:latest",
		"Description": "test",
		"Parameters": "<?xml version='1.0' encoding='UTF-8'?> <parameters>     <parameter name='-a'>grepall</parameter>      <parameter name='-i'>inter</parameter>     <parameter name='-v'>verbose</parameter>     <parameter name='-t'>type</parameter>     <parameter name='-q'>quite</parameter>      <parameter name='-p'></parameter>      <parameter>quicksort</parameter> </parameters>"
		}`)
	c.Request, _ = http.NewRequest("POST", "http://localhost:8080/api/v1/services/add", bytes.NewBuffer(jsonStr))

	// add and verify image in database
	done := AddService(c, true)
	resp := w.Result()

	assert.Equal(t, 200, resp.StatusCode, "Invalid status code while adding service")

	if resp.StatusCode == 200 {
		<-done
	} else {
		return
	}

	// create new context for list Service
	c, w = utils.CreateTestContext()

	// list Service
	ListService(c)
	var response1 responseObj
	resp = w.Result()
	body, _ := ioutil.ReadAll(resp.Body)
	_ = json.Unmarshal([]byte(string(body)), &response1)

	data := response1.Data[0]

	// if status is other than success this will give error
	assert.Equal(t, "success", data.Status, "Error while adding Service")

	// check image exists in docker
	isExists := dockercli.CheckContainerImages("ubuntu")
	assert.Equal(t, true, isExists, "Container Images is not exists in docker container")
}

func TestAddServiceExecutableSuccess(t *testing.T) {
	// after task complete we need to drop all the tables
	defer database.DropTables()
	c, w := utils.CreateTestContext()

	var jsonStr = []byte(`{
		"Name": "test", 
		"EnvironmentId": "1",
		"Type": "executable",
		"ExecutableName": "/home/bgh55259/Downloads/vs_community__1615005248.1562673456.exe",
		"Description": "test",
		"Parameters": "<?xml version='1.0' encoding='UTF-8'?> <parameters>     <parameter name='-a'>grepall</parameter>      <parameter name='-i'>inter</parameter>     <parameter name='-v'>verbose</parameter>     <parameter name='-t'>type</parameter>     <parameter name='-q'>quite</parameter>      <parameter name='-p'></parameter>      <parameter>quicksort</parameter> </parameters>"
		}`)
	c.Request, _ = http.NewRequest("POST", "http://localhost:8080/api/v1/services/add", bytes.NewBuffer(jsonStr))

	// add and verify image in database
	done := AddService(c, true)
	resp := w.Result()

	assert.Equal(t, 200, resp.StatusCode, "Invalid status code while adding service")

	if resp.StatusCode == 200 {
		<-done
	} else {
		return
	}

	// create new context for list Service
	c, w = utils.CreateTestContext()

	// list Service
	ListService(c)
	var response1 responseObj
	resp = w.Result()
	body, _ := ioutil.ReadAll(resp.Body)
	_ = json.Unmarshal([]byte(string(body)), &response1)

	data := response1.Data[0]

	// if status is other than success this will give error
	assert.Equal(t, "success", data.Status, "Error while adding Service")
}

func TestAddServiceMissingMandatoryParameters(t *testing.T) {
	defer database.DropTables()
	c, w := utils.CreateTestContext()

	// missing type in request body
	var jsonStr = []byte(`{
		"Name": "test", 
		"EnvironmentId": "1",
		"ExecutableName": "pwd",
		"ContainerName": "ubuntu:latest",
		"Description": "test",
		"Parameters": "<?xml version='1.0' encoding='UTF-8'?> <parameters>     <parameter name='-a'>grepall</parameter>      <parameter name='-i'>inter</parameter>     <parameter name='-v'>verbose</parameter>     <parameter name='-t'>type</parameter>     <parameter name='-q'>quite</parameter>      <parameter name='-p'></parameter>      <parameter>quicksort</parameter> </parameters>"
		}`)
	c.Request, _ = http.NewRequest("POST", "http://localhost:8080/api/v1/services/add", bytes.NewBuffer(jsonStr))

	// add and verify image in database
	_ = AddService(c, true)
	resp := w.Result()

	assert.Equal(t, 406, resp.StatusCode, "Invalid status code while adding service")
}
