# Insight Engine 
Given the advances in the Digital technologies, Software can provide/replace functionality that has been satisfied previously by physical devices. This is particularly relevant for running diagnostics to provide suitable drug therapy. Insight Engine is the software product which when provided an input in a suitable format, runs predefined sequence of steps with pre-processing and analytical functions, resulting in an acceptable output. The output is used further by the medical practitioners to make informed decisions for the therapy of the patients.

## Features of Insight Engine
* Simple to use web interface 
* Ease of creating and executing pipelines/workflows
* Monitor pipeline execution
* View execution results 

## Installation Procesude
Refer to the installation guide

## User Guide
Refer user guide

## Architecture
