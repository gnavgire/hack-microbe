package main

import (
	"fmt"
	db "SaaMD/middleware/database"
	ctr "SaaMD/middleware/controllers"
	//"context"
	"net/http"
	"github.com/gin-gonic/gin"
	"os"
	"os/signal"
	"syscall"
)
	
func routes(router *gin.Engine) {
	//router.GET("/serviceinstance/get/SiId", getServiceInstance)
	router.GET("/serviceinstance/get/:SiId", ctr.GetService)
	//router.POST("/serviceinstance/add", funcname)
	//router.GET("/pipelineinstance/get/PiId", funcname)
	//router.POST("/pipelineinstance/add", funcname)
}

func main() {
        router := gin.Default()
	//connect with database
        router.Use(db.InitializeDB)

        //Configure routes
        routes(router)
	srv := &http.Server{
                Addr:    ":8181",
                Handler: router,
        }

        go func() {
                // service connections
                if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
                        //log.Error(nil, utils.Concat("listen to", err.Error()))
			fmt.Println("Error in opening socket", err.Error())
                }
        }()

        // Wait for interrupt signal to gracefully shutdown the server with
        // a timeout of 5 seconds.
        quit := make(chan os.Signal, 1)
        // kill (no param) default send syscanll.SIGTERM
        // kill -2 is syscall.SIGINT
        // kill -9 is syscall. SIGKILL but can"t be catch, so don't need add it
        signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
        <-quit

}

func getServiceInstance(c *gin.Context) {
	sname := c.PostForm("name")
	c.JSON(200, gin.H{
                "message": "service instance Successfully",
                "name": sname,
        })
}
