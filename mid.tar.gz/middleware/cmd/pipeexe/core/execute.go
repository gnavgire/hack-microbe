package main

import (
	"fmt"
	"io"
	//"io/ioutil"
	corev1 "k8s.io/api/core/v1"
	//storage "k8s.io/api/storage/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/tools/clientcmd"
	//"net/http"
	"os"
	"os/exec"
	//"path"
	"sync"
	//"time"
	"bytes"
)
//const provisionerPluginName = "kubernetes.io/mock-provisioner"

func executestepcmd(cmd1, cmd2, cmd3 string) {
	cmd := exec.Command(cmd1, cmd2, cmd3)
	var stdoutBuf, stderrBuf bytes.Buffer
	stdoutIn, _ := cmd.StdoutPipe()
	stderrIn, _ := cmd.StderrPipe()

	var errStdout, errStderr error
	stdout := io.MultiWriter(os.Stdout, &stdoutBuf)
	stderr := io.MultiWriter(os.Stderr, &stderrBuf)
	err := cmd.Start()
	if err != nil {
		fmt.Println("cmd.Start() failed with '%s'\n", err)
	}

	var wg sync.WaitGroup
	wg.Add(1)

	go func() {
		_, errStdout = io.Copy(stdout, stdoutIn)
		wg.Done()
	}()

	_, errStderr = io.Copy(stderr, stderrIn)
	wg.Wait()

	err = cmd.Wait()
	if err != nil {
		fmt.Println("cmd.Run() failed with %s\n", err)
	}
	if errStdout != nil || errStderr != nil {
		fmt.Println("failed to capture stdout or stderr\n")
	}
	outStr, errStr := string(stdoutBuf.Bytes()), string(stderrBuf.Bytes())
	fmt.Printf("\nout:\n%s\nerr:\n%s\n", outStr, errStr)
}

func main() {
	fmt.Println("Starting Informer to get pod status")
	kubeconfig := os.Getenv("KUBECONFIG")
	//fmt.Println(kubeconfig)
	config, err := clientcmd.BuildConfigFromFlags("", kubeconfig)
	//fmt.Println(config)
	if err != nil {
		fmt.Println(err.Error())
	}
	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		fmt.Println(err.Error())
	}

	// build the pod defination we want to deploy
	pod := getPodObject()

	// now create the pod in kubernetes cluster using the clientset
	pod, err = clientset.CoreV1().Pods("default").Create(pod)
	if err != nil {
		panic(err)
	}
	fmt.Println("Pod created successfully...")

	// build the pod defination we want to deploy
	pv := createPV("fake-pv-ganesh", "/tmp/foo", "1G", []corev1.PersistentVolumeAccessMode{corev1.ReadWriteMany}, corev1.PersistentVolumeReclaimRecycle)
	//create pv
	_, err = clientset.CoreV1().PersistentVolumes().Create(pv)
	if err != nil {
		panic(err)
	}
	fmt.Println("PV created successfully...")

	/*
	storageClass := storage.StorageClass{
                TypeMeta: metav1.TypeMeta{
                        Kind: "StorageClass",
                },
                ObjectMeta: metav1.ObjectMeta{
                        Name: "gold",
                },
                Provisioner: provisionerPluginName,
        }
        clientset.StorageV1().StorageClasses().Create(&storageClass)
	*/

	// build the pod defination we want to deploy
	pvc := createPVC("fake-pvc-ganesh", "default", "1G", []corev1.PersistentVolumeAccessMode{corev1.ReadWriteMany}, "")
	//create pvc
	_, err = clientset.CoreV1().PersistentVolumeClaims("default").Create(pvc)
	if err != nil {
		panic(err)
	}
	fmt.Println("PVC created successfully...")

	// deleting a claim releases the volume, after which it can be recycled
	/*
		        if err := clientset.CoreV1().PersistentVolumeClaims(ns.Name).Delete(pvc.Name, nil); err != nil {
		                t.Errorf("error deleting claim %s", pvc.Name)
		        }
			testClient.Core().PersistentVolumes().DeleteCollection(nil, metav1.ListOptions{})
	*/
	return

}

/*
func watchPodObject() {

	label := ""
	for k := range pod.GetLabels() {
		label = k
		break
	}
	watch, err := clientset.CoreV1().Pods("default").Watch(metav1.ListOptions{
		Watch:         true,
		LabelSelector: label,
	})
	if err != nil {
		return
	}

	dn := false
	go func() {

		for event := range watch.ResultChan() {
			//dn := false
			fmt.Printf("Type: %v\n", event.Type)
			p, ok := event.Object.(*corev1.Pod)
			//fmt.Println(p)
			if !ok {
				fmt.Println("unexpected type")
			}
			//fmt.Println(p.Status.ContainerStatuses)
			fmt.Println(p.Status.Phase)
			if p.Status.Phase == corev1.PodSucceeded {
				for _, cst := range p.Status.ContainerStatuses {
					if cst.State.Terminated.Reason == "Completed" {
						fmt.Println("Pod finished execution")
						dn = true
						break
					}
				}
			}
			//Succeeded
			if dn == true {
				//fmt.Println("Exiting outer loop ")
				watch.Stop()
			}
		}
	}()

	for {
		fmt.Println("Waiting for pod completion ")
		time.Sleep(3 * time.Second)
		if dn == true {
			fmt.Println("Completed pod")
			break
		}
	}
}
*/

func getPodObject(pod-name, pvcname, containername, imagename, cmd, mountpath string, args []string) *corev1.Pod {
	return &corev1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Name:      pod-name
			Namespace: "default",
			//Labels: map[string]string{
			//	"app": "demo",
			//},
		},
		Spec: corev1.PodSpec{
			Volumes: []corev1.Volume{
				{
					Name: "task-pv-storage",
					VolumeSource: corev1.VolumeSource{
						PersistentVolumeClaim: &corev1.PersistentVolumeClaimVolumeSource{
							ClaimName: pvcname,
							ReadOnly:  false,
						},
					},
				},
			},
			Containers: []corev1.Container{
				{
					Name:            containername,
					Image:           imagename,
					ImagePullPolicy: corev1.PullIfNotPresent,
					Command:         []string{"/bin/demoinsta.exe"},
					Args:            []string{"/usr/share/step1.xml", "/usr/share/deop2.xml"},
					VolumeMounts: []corev1.VolumeMount{
						{
							Name:      "task-pv-storage",
							MountPath: "/usr/share",
						},
					},
				},
			},
			RestartPolicy: corev1.RestartPolicyNever,
		},
	}
}

/*
func CreatePV() {

	pv := &v1.PersistentVolume{
		ObjectMeta: metav1.ObjectMeta{
			Name: fc.Options.PVName,
			Annotations: map[string]string{
				volumehelper.VolumeDynamicallyCreatedByKey: "fakeplugin-provisioner",
			},
		},
		Spec: v1.PersistentVolumeSpec{
			PersistentVolumeReclaimPolicy: fc.Options.PersistentVolumeReclaimPolicy,
			AccessModes:                   fc.Options.PVC.Spec.AccessModes,
			Capacity: v1.ResourceList{
				v1.ResourceName(v1.ResourceStorage): fc.Options.PVC.Spec.Resources.Requests[v1.ResourceName(v1.ResourceStorage)],
			},
			PersistentVolumeSource: v1.PersistentVolumeSource{
				HostPath: &v1.HostPathVolumeSource{
					Path: fullpath,
				},
			},
		},
	}

}

func CreatePVC(capacity string, accessModes []v1.PersistentVolumeAccessMode) *v1.PersistentVolumeClaim {
	claim := v1.PersistentVolumeClaim{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "dummy",
			Namespace: "default",
		},
		Spec: v1.PersistentVolumeClaimSpec{
			AccessModes: accessModes,
			Resources: v1.ResourceRequirements{
				Requests: v1.ResourceList{
					v1.ResourceName(v1.ResourceStorage): resource.MustParse(capacity),
				},
			},
		},
	}
	return &claim
}
*/

func createPV(name, path, cap string, mode []corev1.PersistentVolumeAccessMode, reclaim corev1.PersistentVolumeReclaimPolicy) *corev1.PersistentVolume {
	return &corev1.PersistentVolume{
		ObjectMeta: metav1.ObjectMeta{Name: name},
		Spec: corev1.PersistentVolumeSpec{
			PersistentVolumeSource:        corev1.PersistentVolumeSource{HostPath: &corev1.HostPathVolumeSource{Path: path}},
			Capacity:                      corev1.ResourceList{corev1.ResourceName(corev1.ResourceStorage): resource.MustParse(cap)},
			AccessModes:                   mode,
			PersistentVolumeReclaimPolicy: reclaim,
		},
	}
}

func createPVC(name, namespace, cap string, mode []corev1.PersistentVolumeAccessMode, class string) *corev1.PersistentVolumeClaim {
	fmt.Println(class)
	return &corev1.PersistentVolumeClaim{
		ObjectMeta: metav1.ObjectMeta{
			Name:      name,
			Namespace: namespace,
		},
		Spec: corev1.PersistentVolumeClaimSpec{
			Resources:        corev1.ResourceRequirements{Requests: corev1.ResourceList{corev1.ResourceName(corev1.ResourceStorage): resource.MustParse(cap)}},
			AccessModes:      mode,
			//StorageClassName: &class,
		},
	}
}
