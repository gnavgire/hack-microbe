package main

import (
	"testing"
)

// TestMain - test to drive external testing coverage
func TestMain(t *testing.T) {
	runMain()
}
