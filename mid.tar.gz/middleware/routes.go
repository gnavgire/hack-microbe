package main

import (
	config "SaaMD/middleware/config"
	controllers "SaaMD/middleware/controllers"
	utils "SaaMD/middleware/utils"
	"github.com/gin-contrib/sessions"
	"github.com/gin-contrib/sessions/cookie"
	"github.com/gin-gonic/gin"
	"net/http"
)

func setupRouter() *gin.Engine {
	router := gin.Default()

	// setting cookie based session for user
	store := cookie.NewStore([]byte("secret"))
	router.Use(sessions.Sessions("scipher", store))

	// add configuration in Request
	router.Use(func(c *gin.Context) {
		configuration := config.GetConfig()
		c.Set("Config", configuration)
		c.Next()
	})

	// create default session
	router.Use(func(c *gin.Context) {
		user := utils.GetSession(c)

		if len(user) == 0 {
			User := make(map[string]string)
			User["isLoggedIn"] = "false"
			utils.SaveSession(c, User)
		}
		c.Next()
	})

	//set Default response headers
	router.Use(func(c *gin.Context) {
		origin := c.GetHeader("origin")
		if origin != "" {
			c.Header("Access-Control-Allow-Origin", origin)
		}
		c.Header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, PATCH, DELETE")
		c.Header("Access-Control-Allow-Headers", "Cookie, X-Requested-With,content-type,secKey,AuthKey")
		c.Header("Access-Control-Allow-Credentials", "true")
		method := c.Request.Method

		if method == "OPTIONS" {
			c.String(http.StatusOK, "")
			return
		}
		c.Next()
	})

	return router
}

func authRequired(c *gin.Context) {
	user := utils.GetSession(c)
	if user["isLoggedIn"] == "false" {
		c.Abort()
		c.JSON(401, gin.H{
			"message": "Unauthorized user",
		})
		return
	} 
	c.Next()
}

func routes(router *gin.Engine) {

	v1 := router.Group("/api/v1")
	{
		// users apis
		users := v1.Group("/users")
		{
			users.POST("/sign-in", controllers.UserSignIn)
			users.POST("/sign-up", controllers.UserSignUp)
			users.GET("/session", controllers.UserSession)
		}

		//v1.Use(authRequired)
		//{
			users.GET("/sign-out", controllers.UserSignOut)

			// datasource apis
			ds := v1.Group("ds")
			{
				ds.POST("/upload", controllers.NewDatasource)
				ds.GET("/list", controllers.ListDatasource)
			}

			// images apis
			images := v1.Group("/container-image")
			{
				// define channel in add image to run test cases
				images.POST("/add", func(c *gin.Context) {
					_ = controllers.AddImage(c)
					c.Next()
				})
				images.GET("/list", controllers.ListImage)
			}

			// microservice apis
			services := v1.Group("/services")
			{
				// define channel in add service to run test cases
				services.POST("/add", func(c *gin.Context) {
					_ = controllers.AddService(c)
					c.Next()
				})
				services.GET("/list", controllers.ListService)
				services.DELETE("/delete/:serviceId", controllers.DeleteService)
			}

			// Pipeline apis
			pipeline := v1.Group("/pipeline")
			{
				pipeline.POST("/add", func(c *gin.Context) {
					controllers.AddPipeline(c)
					c.Next()
				})
				pipeline.GET("/list", controllers.ListPipeline)
				pipeline.GET("/get/:pipelineId", controllers.GetPipeline)
				//pipeline.POST("/execute/:pipelineId", controllers.ExecutePipeline)
			}
		//}
	}

	// only if we are in testMode should we attempt to add the death blow
	if testMode {
		// death blow endpoint - endpoint that will stop the service if stop is
		// a live channel (only live if started from RunMain)
		router.POST("/stop", func(c *gin.Context) {
			c.String(200, "success")
			// end the graceful server if being run from RunMain()
			stop <- true
		})
	}

}
